//
//  ContentView.swift
//  Venn
//
//  Created by Shaleen Thaker on 5/19/25.
//

import UIKit
import Foundation
import SwiftUI


class ViewController: UIViewController {

    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var statusLabel: UILabel!

    @IBAction func loginTapped(_ sender: UIButton) {
        let username = usernameField.text ?? ""
        let password = passwordField.text ?? ""

        if username == "Admin" && password == "Password" {
            statusLabel.text = "Login successful!"
            statusLabel.textColor = .systemGreen
        } else {
            statusLabel.text = "Invalid credentials"
            statusLabel.textColor = .systemRed
        }
    }
}
// UserAccount.swift
struct UserAccount: Codable {
    var username: String
    var password: String
}

// Global class to hold user data
class UserSession: ObservableObject {
    @Published var currentUser: UserAccount?
    
    static let shared = UserSession()
    
    private init() { loadUser() }
    
    func loadUser() {
        if let data = UserDefaults.standard.data(forKey: "SavedUser"),
           let user = try? JSONDecoder().decode(UserAccount.self, from: data) {
            self.currentUser = user
        }
    }
    
    func saveUser(_ user: UserAccount) {
        if let data = try? JSONEncoder().encode(user) {
            UserDefaults.standard.set(data, forKey: "SavedUser")
            self.currentUser = user
        }
    }
}

// ContentView.swift

struct ContentView: View {
    @State private var username = ""
    @State private var password = ""
    @State private var isSignUp = false
    @State private var message = ""
    @State private var navigateToCollegeSelect = false

    @ObservedObject var session = UserSession.shared

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Text(isSignUp ? "Sign Up" : "Login")
                    .font(.largeTitle)
                    .bold()

                TextField("Username", text: $username)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                SecureField("Password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())

                Button(isSignUp ? "Create Account" : "Login") {
                    if isSignUp {
                        let newUser = UserAccount(username: username, password: password)
                        session.saveUser(newUser)
                        message = "Account created!"
                    } else {
                        if let saved = session.currentUser,
                           saved.username == username,
                           saved.password == password {
                            navigateToCollegeSelect = true
                        } else {
                            message = "Invalid login"
                        }
                    }
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)

                Text(message)
                    .foregroundColor(.gray)

                NavigationLink(
                destination: CollegeSelect(),
                isActive: $navigateToCollegeSelect,
                label: {
                    EmptyView() // Invisible NavigationLink trigger
                })

                Button(isSignUp ? "Already have an account? Log in" : "Don't have an account? Sign up") {
                    isSignUp.toggle()
                    message = ""
                }
                .foregroundColor(.blue)
                .padding(.top, 10)
            }
            .padding()
        }
    }
}


#Preview {
    ContentView()
}

//@State private var navigateToCollegeSelect = false
/*NavigationLink(
destination: CollegeSelect(),
isActive: $navigateToCollegeSelect,
label: {
    EmptyView() // Invisible NavigationLink trigger
})*/
