//
//  VennTests.swift
//  VennTests
//
//  Created by Shaleen Thaker on 5/19/25.
//

import Testing
@testable import Venn

struct VennTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
