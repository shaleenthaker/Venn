//
//  VennApp.swift
//  Venn
//
//  Created by Shaleen Thaker on 5/19/25.
//

import SwiftUI

@main
struct VennApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
