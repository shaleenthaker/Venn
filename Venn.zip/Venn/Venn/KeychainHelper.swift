import Foundation
import Security
import UIKit
import Foundation
import SwiftUI

class KeychainHelper {
    static func save(key: String, value: String) {
        let data = Data(value.utf8)
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrAccount: key,
            kSecValueData: data
        ] as CFDictionary

        SecItemDelete(query)
        SecItemAdd(query, nil)
    }

    static func read(key: String) -> String? {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrAccount: key,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ] as CFDictionary

        var dataTypeRef: AnyObject?
        if SecItemCopyMatching(query, &dataTypeRef) == noErr,
           let data = dataTypeRef as? Data,
           let value = String(data: data, encoding: .utf8) {
            return value
        }
        return nil
    }

    static func delete(key: String) {
        let query = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrAccount: key
        ] as CFDictionary

        SecItemDelete(query)
    }
}

enum AuthStep {
    case signUp
    case login
    case main
}

struct RootView: View {
    @State private var isLoggedIn = false

    var body: some View {
        Group {
            if isLoggedIn {
                MainView(onLogout: {
                    KeychainHelper.delete(key: "username")
                    KeychainHelper.delete(key: "password")
                    isLoggedIn = false
                })
            } else {
                AuthView(onAuthSuccess: {
                    isLoggedIn = true
                })
            }
        }
        .onAppear {
            let username = KeychainHelper.read(key: "username")
            let password = KeychainHelper.read(key: "password")
            isLoggedIn = username != nil && password != nil
        }
    }
}





struct AuthView: View {
    var onAuthSuccess: () -> Void

    @State private var username = ""
    @State private var password = ""
    @State private var message = ""
    @State private var isSignUp = false

    var body: some View {
        VStack(spacing: 20) {
            Text(isSignUp ? "Sign Up" : "Login")
                .font(.largeTitle)
                .bold()

            TextField("Username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)

            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)

            Button(isSignUp ? "Create Account" : "Log In") {
                handleAuth()
                //print("Login button pressed")
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(isSignUp ? Color.blue : Color.green)
            .foregroundColor(.white)
            .cornerRadius(10)

            Text(message)
                .foregroundColor(.red)
                .multilineTextAlignment(.center)

            Button(isSignUp ? "Already have an account? Log In" : "Don't have an account? Sign Up") {
                isSignUp.toggle()
                message = ""
            }
            .foregroundColor(.blue)
            .padding(.top, 10)
        }
        .padding()
    }

    func handleAuth() {
        guard !username.isEmpty, !password.isEmpty else {
            message = "Please enter both username and password."
            return
        }

        if isSignUp {
            // Save to Keychain
            KeychainHelper.save(key: "username", value: username)
            KeychainHelper.save(key: "password", value: password)
            message = "Account created!"
            isSignUp = false
        } else {
            // Log in
            let savedUsername = KeychainHelper.read(key: "username")
            let savedPassword = KeychainHelper.read(key: "password")

            if username == savedUsername && password == savedPassword {
                onAuthSuccess()
            } else {
                message = "Invalid username or password."
            }
        }
    }
}


struct MainView: View {
    var onLogout: () -> Void
    
    @State private var searchText = ""
    @State private var selectedOption = ""
    @State private var showDropdown = false

    let options = [
        "Brown University",
        "Cornell University",
        "Georgia Institute of Technology",
        "Stanford University",
        "University of California: Los Angeles",
        "University of California: San Diego",
        "University of Florida",
        "University of Illinois Urbana-Champaign",
        "University of Michigan",
        "University of Virginia",
        "Tufts University",
        "Villanova University",
        "Washington University in St. Louis"
    ]
    
    var filteredOptions: [String] {
        if searchText.isEmpty {
            return options
        } else {
            return options.filter { $0.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Selected: \(selectedOption)")
                .padding(.bottom)

            TextField("Select Option", text: $searchText, onEditingChanged: { editing in
                withAnimation {
                    showDropdown = editing
                }
            })
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding(.horizontal)

            if showDropdown {
                ScrollView {
                    VStack(alignment: .leading, spacing: 0) {
                        ForEach(filteredOptions, id: \.self) { option in
                            Button(action: {
                                selectedOption = option
                                searchText = option
                                showDropdown = false
                            }) {
                                Text(option)
                                    .padding()
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .background(Color.white)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                    .padding(.horizontal)
                }
                .frame(maxHeight: 150)
            }

            Spacer()
        }
        .padding()
            Button("Log Out") {
                KeychainHelper.delete(key: "username")
                KeychainHelper.delete(key: "password")
                onLogout()
            }
            .padding()
            .background(Color.red)
            .foregroundColor(.white)
            .cornerRadius(8)
        }
    }


struct RootView_Previews: PreviewProvider {
    static var previews: some View {
        RootView()
    }
}



//
//  KeychainHelper.swift
//  Venn
//
//  Created by Shaleen Thaker on 5/19/25.
//

